---
name: agent-experience
description: >-
  Agent experience (AX) principles and developer ergonomics for autonomous AI agents. Use when designing, auditing, or optimizing agent workflows, feedback loops, non-blocking background task management, and structured progress reporting.
---

# Agent Experience (AX) Skill

Best practices and architectural principles for maximizing Developer & Agent Experience (AX) in autonomous coding, decision support, and case management harnesses.

## Core Principles
1. **Terse & Actionable Communication**:
   - Provide direct answers before explanations.
   - Retain every concrete fact, error message, number, and file path.
   - Avoid performative filler, generic pleasantries, and unnecessary token expansion.

2. **Non-Blocking Background Tasks & Reactive Wakeup**:
   - Long-running processes (compiles, test suites, OCR inference, large scrapes) run asynchronously.
   - Never busy-wait or poll in tight loops; allow reactive wakeups from completion notifications.

3. **Empirical Verification First**:
   - Verify every assertion with real runtime evidence before claiming task completion.
   - Use clean worktrees to isolate experimental changes and protect working branch integrity.

4. **Transparent State & Persistent Artifacts**:
   - Maintain single sources of truth in project state records.
   - Keep artifacts structured, auditable, and easily navigable for human oversight.
