---
name: agentic-awesome-skills
description: >-
  Catalog and on-demand loader for the 1,300+ skills in sickn33/agentic-awesome-skills. Use when you need a specialized domain skill (security auditing, cloud/DevOps, data engineering, specific framework runbooks) from the agentic-awesome-skills collection.
---

# Agentic Awesome Skills Catalog (`sickn33/agentic-awesome-skills`)

Source repository: `https://github.com/sickn33/agentic-awesome-skills`
Local staging catalog path: `C:\Users\polic\.codex\skills\agentic-awesome-skills\catalog\`

## How to Use
1. To avoid bloating context on every turn, only high-frequency skills (`shadcn`, `ui-motion`, `fixing-motion-performance`, `design-taste-frontend`) are mounted at the top level of `C:\Users\polic\.codex\skills\`.
2. Additional skills from `sickn33/agentic-awesome-skills` are stored in `C:\Users\polic\AppData\Local\Temp\gpc-skill-staging\agentic-awesome-skills\skills\` (and indexed in `C:\Users\polic\.codex\skills\agentic-awesome-skills\skills-index.txt`).
3. When a task requires a specialized skill from the collection, search `skills-index.txt` and read or copy that specific `<skill>/SKILL.md` into `C:\Users\polic\.codex\skills\<skill>\`.
