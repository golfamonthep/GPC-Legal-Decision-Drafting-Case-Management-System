---
name: deepseek-harness
description: >-
  DeepSeek Harness architecture and provider-neutral AI harness best practices (deepseek-ai/deepseek-harness). Use when designing, auditing, or extending AI harnesses, plugin boundaries, structured JSON Schema outputs, fail-closed error handling, CoT leakage trimming, and DeepSeek API integrations.
---

# DeepSeek Harness Skill

Source repository: `https://github.com/deepseek-ai/deepseek-harness`
Companion skills installed in this environment:
- `dsh-code-review`, `dsh-error-handling`, `dsh-find-simplifications`, `dsh-pre-push-checks`, `dsh-trim-cot-leakage`, `dsh-client-ui-ux`, `dsh-responsive-ui`, `dsh-speed-up-perf`, `dsh-prose-standard`, `dsh-doc`.

## Core Principles
1. **Everything Behind a Explicit Harness Boundary**:
   - Keep provider transport (`POST /responses` or `/chat/completions`), authentication, timeout, payload size limits, and schema validation inside a single auditable harness module (`shared/ai-harness.mjs`).
   - Application routes and UI components must never call provider SDKs or raw `fetch` to LLM endpoints directly.
2. **Fail-Closed & Zero Silent Fallbacks**:
   - Require `AI_ENABLED=true` and `AI_API_KEY` before any external request.
   - Disable tools (`tools: []` / omitted), web search, and provider-side storage (`store: false`).
   - Validate structured output against a strict JSON Schema (`additionalProperties: false`) and reject truncated/incomplete responses (`status !== 'completed'`).
3. **Trim CoT Leakage & Redact Sensitive Data**:
   - Strip or reject leaked chain-of-thought tags (`<think>...</think>`) before parsing structured JSON.
   - Pseudonymize PII/case identifiers before sending prompts and verify that no foreign tokens or unapproved citations appear in the response.
4. **Stale Revision Protection**:
   - Capture baseline revision timestamps/locks before invoking the model and re-verify immediately after the model returns (`409 Conflict` on mismatch) so AI output never overwrites concurrent human edits.
