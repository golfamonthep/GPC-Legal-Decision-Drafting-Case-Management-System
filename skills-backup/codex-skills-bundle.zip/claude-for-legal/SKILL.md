---
name: claude-for-legal
description: Comprehensive legal engineering and statutory analysis skill from anthropics/claude-for-legal. Use when selecting, auditing, analyzing, modernizing, and drafting legal texts, contracts, administrative regulations, compliance gap analyses, litigation matters, and government decisions.
---

# Claude for Legal (Anthropic)

## Overview
A comprehensive suite of legal and statutory intelligence tools designed for legal professionals, hearing examiners, and judicial bodies. It provides specialized capabilities for statutory analysis, litigation preparation, regulatory tracking, and legal memo drafting.

## Core Capabilities
- **Statutory Modernization & Currency**: Review and verify active vs. repealed statutes, sunset clauses, and amending acts.
- **Litigation & Case Analysis**: Build issue matrices, chronological event graphs, evidence maps, and claim charts.
- **Regulatory Gap Analysis**: Cross-reference administrative orders, police regulations, and constitutional provisions.
- **Legal Decision & Brief Drafting**: Frame findings of fact, conclusions of law, and dispositive reasoning.
